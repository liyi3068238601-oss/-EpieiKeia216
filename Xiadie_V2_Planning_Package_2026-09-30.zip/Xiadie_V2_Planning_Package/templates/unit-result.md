# 单元执行结果

- task_id：填写本单元ID
- attempt_id / owner：填写唯一尝试与执行者
- 状态：ready_for_review / blocked / blocked_external / rejected
- base_commit / head_commit：必须是真实commit；研究任务写“不适用”并给文件hash
- 依赖验收：逐项给前置结果路径
- 授权范围：工作区、文件、网络、模型费用、外部动作

## 1. 本次实际完成
只写发生过的动作和结果，不把计划当执行。

## 2. 现成方案与代码来源
source IDs、固定commit、采用决定ID、许可、直接依赖/适配/移植/借鉴的具体文件。

## 3. 修改与证据
列新增/修改文件、diff、测试fixture和产物hash。用户未提交内容未改动的检查结果。

## 4. 实际命令与结果
逐条列cwd、argv、开始/结束、exit code、输出文件。区分mock、真实Runtime、真实模型、Windows发行包。

## 5. 验收逐项判定
每一条写pass/fail/not_run及证据。不要只写“全部通过”。

## 6. 风险、阻塞与替代方案
缺Key/缺权限/缺资源/接口不支持分别说明；已有搜索与最小复现路径。

## 7. 回滚
代码revert、数据恢复与不能撤销的外部效果；禁止清用户改动。

## 8. 下一步与交接
下一可执行ID、必须知道的事实、尚未生效的候选；不共享无关私密记忆。

## 9. 独立review
由审查者填写精确reviewed head、复跑命令和结果。作者不填自己已accepted。
