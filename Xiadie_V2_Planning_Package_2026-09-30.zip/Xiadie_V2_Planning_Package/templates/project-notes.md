# 项目笔记编写模板（不是原生MEMORY.md替代物）

适用project_id：
来源commit/日期：

## 非显然工程事实
只记无法直接从源码/测试/AGENTS读出的经验。注明Why、How to apply和来源。

## 当前有效约束
与已合并ADR/真实实现一致；过时项标superseded，不按Life半衰期删除。

## 参考指针
指向测试、ADR、文档和真实产物；不要复制整份代码结构或用户Life。

## 待核对
无法确认的旧事实保持unknown/stale，不能写成当前真相。

## 实时任务状态
只链接权威task ledger，不在此复制Owner、进度和所有检查点。

原生ZCode MEMORY.md只写一行一个索引，具体事实按固定版本原生格式保存；必须由adapter或原生流程更新。
