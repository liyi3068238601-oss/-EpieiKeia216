# 跨Agent工作包与交接

- task_id / attempt_id / parent_run_id：
- owner / lease_generation / expiry：
- project_id / workspace / base_commit：
- 目标：
- 禁止事项与allowed paths/tools/network：
- 总预算 / 子代理上限 / 最大深度：
- 依赖版本 / 必要AGENTS片段 / 工程知识引用：
- 产物与验收测试：

## 当前检查点
已完成的具体步骤、head_commit、产物hash、测试结果、尚未发生的动作。

## 未知外部效果
operation_id、目标、是否收到receipt、是否可安全重试。未知不视为失败未执行。

## 问题/阻塞
只在本任务内讨论，给来源和版本。

## 返回
status=ready_for_review/partial/failed/unknown_effect；不直接修改主分支、主项目正式结论或Life。
