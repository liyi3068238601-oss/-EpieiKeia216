#!/usr/bin/env python3
"""Validate this planning package only. No network, installs, or product execution."""
from pathlib import Path
import json, re, sys
root = Path(__file__).resolve().parent.parent
errors = []
def load(name):
    try: return json.loads((root/name).read_text(encoding="utf-8"))
    except Exception as e:
        errors.append(f"{name}: {e}"); return {}
tasks=load("tasks.json").get("tasks",[])
sources=load("sources.json").get("sources",[])
reqs=load("requirements.json").get("requirements",[])
stages=load("versions.json").get("stages",[])
ids={x.get("id") for x in tasks}; sids={x.get("id") for x in sources}; rids={x.get("id") for x in reqs}
if len(ids)!=len(tasks): errors.append("Duplicate task ID")
if len(sids)!=len(sources): errors.append("Duplicate source ID")
if len(rids)!=len(reqs): errors.append("Duplicate requirement ID")
for t in tasks:
    tid=t.get("id","")
    if not re.fullmatch(r"P\d{2}-U\d{2}",tid): errors.append(f"Bad task ID: {tid}")
    for key in ("scope","objective","tests","accept","deliverable","evidence_path"):
        if not t.get(key): errors.append(f"{tid}: missing {key}")
    if len(t.get("steps",[]))<3: errors.append(f"{tid}: fewer than 3 concrete steps")
    if not t.get("sources"): errors.append(f"{tid}: no sources")
    for s in t.get("sources",[]):
        if s not in sids: errors.append(f"{tid}: unknown source {s}")
    for d in t.get("dependencies",[]):
        if d not in ids: errors.append(f"{tid}: unknown dependency {d}")
    for r in t.get("requirements",[]):
        if r not in rids: errors.append(f"{tid}: unknown requirement {r}")
    if t.get("status")!="not_started": errors.append(f"{tid}: planning copy must start not_started")
    if not (root/"tasks"/(tid+".md")).is_file(): errors.append(f"{tid}: missing card")
byid={t["id"]:t for t in tasks}; seen=set(); active=set()
def visit(tid):
    if tid in active:
        errors.append(f"Dependency cycle at {tid}"); return
    if tid in seen or tid not in byid:return
    active.add(tid)
    for dep in byid[tid]["dependencies"]: visit(dep)
    active.remove(tid); seen.add(tid)
for tid in byid:visit(tid)
for s in stages:
    group=[t for t in tasks if t["stage"]==s["code"]]
    if len(group)<5:errors.append(f"{s['code']}: too few tasks")
    if [t["kind"] for t in group[:2]] != ["research","spike"]:errors.append(f"{s['code']}: missing find/try gates")
    if group[-1]["id"]!=s["gate_task"] or group[-1]["kind"]!="gate":errors.append(f"{s['code']}: bad release gate")
    if any(t["version"]!=s["version"] for t in group):errors.append(f"{s['code']}: version mismatch")
for r in reqs:
    if not r.get("task_ids"):errors.append(f"{r['id']}: unmapped requirement")
    for tid in r.get("task_ids",[]):
        if tid not in ids:errors.append(f"{r['id']}: unknown task {tid}")
for name in ("00_阅读与执行入口.md","01_项目计划书.md","02_计划执行书.md","03_代码参考与复用清单.md","04_需求追踪矩阵.md","05_执行单元索引.md"):
    if not (root/name).is_file():errors.append(f"Missing book {name}")
summary={"planning_validation":"FAIL" if errors else "PASS","stages":len(stages),"tasks":len(tasks),"requirements":len(reqs),"sources":len(sources),"product_tests_run":False,"errors":errors}
print(json.dumps(summary,ensure_ascii=False,indent=2))
sys.exit(bool(errors))
